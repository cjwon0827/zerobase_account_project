package com.example.Account.type;

public enum TransactionResultType {
    S,F
}
