package com.example.Account.type;

public enum AccountStatus {
    IN_USE,
    UNREGISTRED,
}
