package com.example.Account.type;

public enum TransactionType {
    USE, CANCEL
}
